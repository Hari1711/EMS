from django.contrib import admin
from myapp.models import EnergyMeter
# Register your models here.

admin.site.register(EnergyMeter)